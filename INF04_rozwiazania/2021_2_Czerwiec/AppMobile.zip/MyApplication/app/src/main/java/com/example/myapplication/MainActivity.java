package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.Editable;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout);

        EditText email = (EditText) findViewById(R.id.edit_text1);
        EditText passowrd = (EditText) findViewById(R.id.edit_text2);
        EditText repeatpassword = (EditText) findViewById(R.id.edit_text3);
        TextView wynik = (TextView) findViewById(R.id.view_text4);

        Button button = (Button) findViewById(R.id.button);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String napis = "";
                String napish ="";
                String napise ="";

                String pobranyemail = String.valueOf(email.getText());

                boolean jestmalpa = pobranyemail.contains("@");

               int rowne = 2;

               String haslo1 = String.valueOf(passowrd.getText());
               String haslo2 = String.valueOf(repeatpassword.getText());

                if (haslo1.equals(haslo2))
                    rowne = 1;
                 else
                     rowne = 0;

                if (!jestmalpa)
                    napise ="Nieprawidłowy adres e-mail";

                if (rowne == 0)
                    napish = "Hasła się różnią";

               if ((!jestmalpa) && (rowne < 1))
                   napis = napise + "\n" + napish;
                else
                    if (!jestmalpa) napis = napise;
                     else
                    if (rowne == 0)
                        napis = napish;
                     else
                         napis = "Witaj " + pobranyemail;


                wynik.setText(napis);

            }
        });

    }


}
