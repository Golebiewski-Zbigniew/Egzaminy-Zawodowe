package com.example.myapplication2;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    int ile = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout);

        TextView stan = (TextView) findViewById(R.id.textView2);

        Button polub = (Button) findViewById(R.id.button1);
        polub.setBackgroundColor(Color.parseColor("#008080"));

        polub.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ile = ile + 1;

                stan.setText(ile + " polubień");

            }
        });

        Button usun = (Button) findViewById(R.id.button2);
        usun.setBackgroundColor(Color.parseColor("#008080"));
        usun.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (ile == 0)
                    stan.setText("0 polubień");
                 else {
                     ile = ile - 1;
                    stan.setText(ile + " polubień");
                }

            }
        });

        Button zapisz = (Button) findViewById(R.id.button3);
        zapisz.setBackgroundColor(Color.parseColor("#008080"));


    }
}